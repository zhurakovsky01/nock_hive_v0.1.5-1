####################################################################################
##
## iGoTeK NOCK Prover v0.1.5+1
##
####################################################################################

#!/usr/bin/env bash

. /hive/miners/custom/nock/h-manifest.conf

accepted_shares=$(grep -c "Heartbeat success" "$CUSTOM_LOG_BASENAME.log")
rejected_shares=0

# Get the latest GPU stats table from log
stats_raw=`cat $CUSTOM_LOG_BASENAME.log | grep "INFO Card-0 speed" | tail -n 1`
echo "stats_raw: $stats_raw"

#Calculate miner log freshness
maxDelay=120
time_now=$(date -u +%s)  # UTC
echo "time_now : $time_now"

# Check if we have valid stats data
if [[ -n "$stats_raw" ]]; then
    # Extract total hashrate from string like "Total | tip5: 40.05 MH/s"
    total_hashrate_str=`echo $stats_raw | grep -o '[0-9.]* p/s' | cut -d' ' -f1`
    total_hashrate=`echo "$total_hashrate_str * 1000" | bc | cut -d'.' -f1`
    diffTime=0
fi

echo "diffTime : $diffTime"

if [ "$diffTime" -lt "$maxDelay" ]; then
        echo "total_hashrate : $total_hashrate"

        #START - GPU Status: Hashrates
        gpu_stats=$(< $GPU_STATS_JSON)
        
        echo "GPU_STATS_JSON=$GPU_STATS_JSON" >&2
        ls -l "$GPU_STATS_JSON" >&2
        jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' "$GPU_STATS_JSON" >&2

        readarray -t gpu_stats < <( jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' $GPU_STATS_JSON 2>/dev/null)
        busids=(${gpu_stats[0]})
        brands=(${gpu_stats[1]})
        temps=(${gpu_stats[2]})
        fans=(${gpu_stats[3]})
        gpu_count=${#busids[@]}

        hash_arr=()
        busid_arr=()
        fan_arr=()
        temp_arr=()
        lines=()

        if [ $(gpu-detect NVIDIA) -gt 0 ]; then
                brand_gpu_count=$(gpu-detect NVIDIA)
                BRAND_MINER="nvidia"
        elif [ $(gpu-detect AMD) -gt 0 ]; then
                brand_gpu_count=$(gpu-detect AMD)
                BRAND_MINER="amd"
        fi
        total_hashrate_sum=0
        # Determine shift for integrated video card
        [[ ${brands[0]} == 'cpu' ]] && internalCpuShift=1 || internalCpuShift=0
        
        for(( i=0; i < gpu_count; i++ )); do
                # Filter integrated video card (cpu)
                if [[ "${brands[i]}" == 'cpu' ]]; then
                    continue
                fi
                
                [[ "${busids[i]}" =~ ^([A-Fa-f0-9]+): ]]
                busid_arr+=($((16#${BASH_REMATCH[1]})))
                temp_arr+=(${temps[i]})
                fan_arr+=(${fans[i]})                
                
                # Calculate correct GPU index considering integrated video card
                gpu_index_for_log=$i
                if [[ $internalCpuShift -eq 1 ]]; then
                    gpu_index_for_log=$((i - internalCpuShift))
                fi
                
                # Search for GPU hashrate in new table format
                gpu_raw=$(grep "Card-$gpu_index_for_log" "$CUSTOM_LOG_BASENAME.log" | grep "p/s" | tail -n 1 | tr -d '\000')
                
                echo "gpu_raw : $gpu_raw"  
                
                if [[ -n "$gpu_raw" ]]; then
                    # Extract hashrate from string like "2025-10-20T20:57:15.537819Z  INFO Card-0 speed:  5.83 p/s"
                    hashrate_str=$(echo "$gpu_raw" | grep -o '[0-9.]* p/s' | cut -d' ' -f1)
		    # Convert the hashrate to MH/s
                    hashrate=$(echo "$hashrate_str * 1000000" | bc | cut -d'.' -f1)
                fi

                echo "hashrate: $hashrate"
                hashrate_khs=$(echo "scale=2; $hashrate" | bc)
                hash_arr+=($hashrate_khs)		
                total_hashrate_sum=$((total_hashrate_sum + hashrate))
                echo "hash_arr : $hash_arr (MH/s)"
        done
	#FINISH - GPU Status: Hashrates

        hash_json=`printf '%s\n' "${hash_arr[@]}" | jq -cs '.'`
        bus_numbers=`printf '%s\n' "${busid_arr[@]}"  | jq -cs '.'`
        fan_json=`printf '%s\n' "${fan_arr[@]}"  | jq -cs '.'`
        temp_json=`printf '%s\n' "${temp_arr[@]}"  | jq -cs '.'`

        uptime=$(( `date +%s` - `stat -c %Y $CUSTOM_CONFIG_FILENAME` ))

        #Compile stats/mhs
	stats=$(jq -nc \
	    --argjson hs "$hash_json" \
	    --arg ver "$CUSTOM_VERSION" \
	    --arg ths "$total_hashrate" \
	    --argjson bus_numbers "$bus_numbers" \
	    --argjson fan "$fan_json" \
	    --argjson temp "$temp_json" \
	    --arg uptime "$uptime" \
	    --argjson accepted "$accepted_shares" \
	    --argjson rejected "$rejected_shares" \
	    '{ hs: $hs, hs_units: "hs", algo : "NOCK", ver:$ver , uptime: $uptime, ar: [$accepted,$rejected], bus_numbers: $bus_numbers, temp: $temp, fan: $fan }')
        #khs=$total_hashrate
        khs=$(echo "scale=2; $total_hashrate_sum/1000" | bc)
else
  khs=0
  stats="null"
fi

echo Debug info:
echo Log file : $CUSTOM_LOG_BASENAME.log
echo Time since last log entry : $diffTime
echo Raw stats : $stats_raw
echo MHS : $khs
echo Output : $stats

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
