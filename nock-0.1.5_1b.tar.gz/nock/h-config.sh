#!/usr/bin/env bash

# Stop if there is no %WAL%
# [[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1

# Stop if there is no pool address
# [[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 1

# Config: algo + wallet + pool
# conf="--algo=${CUSTOM_ALGO} --wallet=${CUSTOM_TEMPLATE} --pool=${CUSTOM_URL}"

# Config: pubkey + name
conf="--pubkey=${CUSTOM_TEMPLATE} --name=${HOSTNAME}"
echo -e "\e[33mWallet: ${CUSTOM_TEMPLATE}\e[0m"
echo -e "\e \e[0m"

# Config: config + password if there is input
[[ ! -z ${CUSTOM_PASS} ]] && conf+=" --pass ${CUSTOM_PASS} "

# Detect CPU cores and calculate initial threads
CPU_CORES=$(nproc)
THREADS=$((CPU_CORES - 1))

# Ensure minimum 1 thread
if [ "$THREADS" -lt 1 ]; then
    THREADS=1
fi

# Detect number of GPUs
GPU_COUNT=$(nvidia-smi -L 2>/dev/null | wc -l)

# Divide threads among GPUs if more than 1
if [ "$GPU_COUNT" -gt 1 ]; then
    THREADS=$(( THREADS / GPU_COUNT ))
 
    # Set THREADS=0 if CPU Cores not enough
    if [ "$THREADS" -lt 1 ]; then
        THREADS=0
    fi

    echo -e "\e[33m[+] CPU Cores: $CPU_CORES, GPUs: $GPU_COUNT, Threads per GPU: $THREADS\e[0m"

    if [ "$THREADS" -eq 1 ]; then
        echo -e "\e[33m[!] CPU is insufficient, hashrate will be very low.\e[0m"
    elif [ "$THREADS" -eq 2 ]; then
        echo -e "\e[33m[!] CPU is insufficient, hashrate will be low.\e[0m"
    fi
else
    echo -e "\e[33m[+] CPU Cores: $CPU_CORES, GPUs: $GPU_COUNT, Threads for GPU: $THREADS\e[0m"
fi

# Set THREADS_PER_CARD variable for later use
THREADS_PER_CARD=$THREADS

# Check if user has provided --threads-per-card manually
if [[ "$CUSTOM_USER_CONFIG" != *"--threads-per-card"* ]]; then
    conf+=" --threads-per-card ${THREADS_PER_CARD}"
else
    echo -e "\e[36m[>] Using user-defined --threads-per-card value (auto CPU thread setting skipped)\e[0m"
fi

# Config: config + extra config arguments
conf+=" ${CUSTOM_USER_CONFIG}"

# Stop if there is no name for $CUSTOM_CONFIG_FILENAME
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && return 1

# Create ${CUSTOM_NAME}.conf
echo "$conf" > $CUSTOM_CONFIG_FILENAME
echo -e "\e[33m \e[0m"