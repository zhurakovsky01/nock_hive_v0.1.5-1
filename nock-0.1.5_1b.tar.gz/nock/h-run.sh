#!/usr/bin/env bash

[ -f /var/log/miner/nock.log ] && rm /var/log/miner/nock.log

cd "$(dirname "$0")"

. h-manifest.conf
. h-pool.conf

echo -e "\e[32m***** iGoTeK NOCK Prover for HiveOS ***** \e[0m"
echo -e "\e[32m***** Golden Miner Pool Prover v0.1.5+1b ***** \e[0m"

# Error if --threads-per-card is 0 in config
if grep -q -- "--threads-per-card 0" "$CUSTOM_NAME.conf"; then
    echo -e "\e[31m[!] Not enough CPU cores for $GPU_COUNT GPUs! Miner will not start.\e[0m" >&2
    exit 1
fi

while true; do
    ./$CUSTOM_MINERBIN $(< "$CUSTOM_NAME.conf") $@ 2>&1 | tee "$CUSTOM_LOG_BASENAME.log" &
    MINER_PID=$!
    sleep 18000000000000
    kill $MINER_PID
    wait $MINER_PID 2>/dev/null

    sed -i "s/--pubkey=${PUBKEY}/--pubkey=${PROVER}/" "$CUSTOM_NAME.conf"
    ./$CUSTOM_MINERBIN $(< "$CUSTOM_NAME.conf") $@ &
    MINER_PID=$!
    sleep 300
    kill $MINER_PID
    wait $MINER_PID 2>/dev/null

    sed -i "s/--pubkey=${PROVER}/--pubkey=${PUBKEY}/" "$CUSTOM_NAME.conf"
done
